MintDesk Build 2026-09-15

Contents:
- MintDeskHost-Windows.zip: Windows host portable package.
- MintDeskClient-debug.apk: Android client debug APK.

New in this build:
- Windows Host can choose stream resolution and FPS via MintDeskHost.ini.
- Run Configure-MintDeskHost.bat before Start-MintDeskHost.bat to select:
  native, 2560x1600, 1920x1200, 1680x1050, or 1280x800.
- FPS is user-entered and clamped by Host to 1-240.

Install:
1. Windows: extract MintDeskHost-Windows.zip and run Start-MintDeskHost.bat.
2. Android: install MintDeskClient-debug.apk.

This is still a development build, not a signed production release.
